"""Configuration package for PhilGEPS scraper."""
